---
title: Sphene Architecture & Engine
partition: Reference
tags: [architecture, go, sqlite, wal, mcp, zero-trust]
created: 2026-09-18
---

# Sphene Architecture & Engine Specifications

> [!IMPORTANT]
> The Sphene kernel is designed from the ground up in Go, requiring less than **25MB RAM** in steady-state while delivering sub-millisecond queries over vaults with 100,000+ notes.

## 🏗️ Architectural Topology

```mermaid
graph TD
    Client[Human Web UI & Mobile PWA] --> Router[REST & WebSocket Router]
    Agent[Autonomous AI Agent / Hermes] --> MCP[Native Stdio MCP Gateway]
    Router --> Auth{Argon2id Zero-Trust Auth}
    MCP --> Auth
    Auth --> Kernel[Sphene Sovereign Kernel <25MB]
    Kernel --> FTS[(Embedded SQLite WAL & FTS5)]
    Kernel --> Vault[(Local Plaintext Markdown Vault)]
    Kernel --> Canvas[(Vector Drawing Canvas Studio)]
```

---

## 📊 PKM Architecture Comparison

| Metric | Sphene Hub | Obsidian (Desktop) | Logseq (Desktop) | Notion (Cloud) |
| :--- | :--- | :--- | :--- | :--- |
| **Memory Footprint** | `< 25 MB RAM` | ~150–350 MB | ~300–600 MB | ~500+ MB |
| **Search Engine** | SQLite FTS5 (sub-ms) | JavaScript Regex | Datomic / JS | Cloud Index |
| **Multi-Device Sync** | Local / Zero-Knowledge | Paid Obsidian Sync | Git / Logseq Sync | Cloud Only |
| **Agent Protocol** | Native Stdio MCP | Third-Party Plugins | None | REST Webhooks |
| **Data Sovereignty** | 100% Local Filesystem | Local Filesystem | Local Filesystem | Proprietary Cloud |

---

## 💻 Native Kernel Implementation Snippet

The differential timeline engine computes atomic document changes and guarantees SQLite WAL transaction safety:

```go
package gateway

import (
	"context"
	"fmt"
	"time"
)

// RecordDiff logs atomic revisions into the differential timeline
func (gw *Gateway) RecordDiff(ctx context.Context, path, author, diff string) error {
	tx, err := gw.db.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("failed to initiate wal transaction: %w", err)
	}
	defer tx.Rollback()

	query := `INSERT INTO timeline (path, author, diff_patch, timestamp) VALUES (?, ?, ?, ?)`
	if _, err := tx.ExecContext(ctx, query, path, author, diff, time.Now().UnixMilli()); err != nil {
		return err
	}
	return tx.Commit()
}
```

> [!TIP]
> Return to [[Welcome to Sphene]] or explore [[Quantum Computing & Mathematics]] for mathematical typography.
