---
title: Quantum Computing & Mathematics
partition: Reference
tags: [quantum, physics, mathematics, algorithms, latex]
created: 2026-09-18
---

# Quantum Computing & Mathematical Foundations

> [!NOTE]
> Sphene features first-class native rendering of LaTeX mathematical equations powered by KaTeX. Both inline and display block formulas are compiled instantaneously.

## 🌌 Qubit States & Superposition

In quantum computation, a pure qubit state $|\psi\rangle$ is represented as a linear superposition of the orthonormal basis states $|0\rangle$ and $|1\rangle$:

$$|\psi\rangle = \alpha |0\rangle + \beta |1\rangle = \begin{pmatrix} \alpha \\ \beta \end{pmatrix}$$

Where $\alpha, \beta \in \mathbb{C}$ satisfy the probability normalization constraint:

$$\sum_{i} |c_i|^2 = |\alpha|^2 + |\beta|^2 = 1$$

---

## ⚛️ Time-Dependent Schrödinger Equation

The fundamental equation governing the unitary evolution of a closed quantum state vector is given by:

$$i\hbar \frac{\partial}{\partial t} \Psi(\mathbf{r}, t) = \hat{H} \Psi(\mathbf{r}, t)$$

Where:
- $\hbar \approx 1.0545718 \times 10^{-34} \text{ J}\cdot\text{s}$ is the reduced Planck constant
- $\hat{H}$ is the Hermitian Hamiltonian operator representing total system energy:

$$\hat{H} = -\frac{\hbar^2}{2m} \nabla^2 + V(\mathbf{r}, t)$$

---

## 📐 Important Mathematical Identities

### 1. Gaussian Normal Integral
The continuous probability distribution integral evaluates in closed form:

$$\int_{-\infty}^{\infty} e^{-a x^2} \, dx = \sqrt{\frac{\pi}{a}} \quad (\text{for } a > 0)$$

### 2. Discrete Quantum Fourier Transform (QFT)
The quantum Fourier transform acts on basis state $|j\rangle$ according to:

$$|j\rangle \mapsto \frac{1}{\sqrt{N}} \sum_{k=0}^{N-1} \omega^{j k} |k\rangle, \quad \omega = \exp\left(\frac{2\pi i}{N}\right)$$

---

## 🧮 Quantum Entanglement (Bell State)

The maximally entangled bipartite Bell state $|\Phi^+\rangle$ is defined as:

$$|\Phi^+\rangle = \frac{1}{\sqrt{2}} \left( |00\rangle + |11\rangle \right)$$

```python
import numpy as np

def bell_state():
    """Generates the density matrix of a maximally entangled Bell state"""
    state = np.array([1, 0, 0, 1]) / np.sqrt(2)
    density_matrix = np.outer(state, np.conj(state))
    return density_matrix

print("Bell State Density Matrix:\n", bell_state())
```

> [!TIP]
> See [[Sphene Architecture & Engine]] for how the local relational engine indexes mathematical tokens.
