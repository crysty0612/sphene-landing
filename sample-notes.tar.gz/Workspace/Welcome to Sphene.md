---
title: Welcome to Sphene
partition: Workspace
tags: [welcome, guide, pkm, sovereign]
created: 2026-09-18
---

# Welcome to Sphene Sovereign Second Brain

> [!NOTE]
> Sphene is your zero-trust personal knowledge engine. Everything lives in plaintext Markdown files inside your local vault—no cloud lock-in, no telemetry, and lightning-fast sub-millisecond search.

## ⚡ Quick Start Checklist
- [x] Successfully deployed Sphene sovereign kernel
- [ ] Explore the interactive [[Sphene Architecture & Engine]] technical reference
- [ ] Inspect mathematical formula rendering in [[Quantum Computing & Mathematics]]
- [ ] Open the visual diagram in [[System Architecture]] using the **Draw** studio
- [ ] Connect your local agent using native MCP (`sphene mcp`)

---

## 🧭 Vault Navigation & Organization
Your knowledge base is structured into isolated sovereign partitions:

| Partition | Purpose | Access Control |
| :--- | :--- | :--- |
| **Workspace** | Active projects, daily logs, and sprint tasks | Unrestricted read/write |
| **Reference** | Evergreen notes, documentation, and specs | Structured reference |
| **Private** | Confidential records, keys, and journals | Sovereign encrypted storage |

> [!TIP]
> You can link any two notes using standard wikilinks: `[[Note Name]]` or `[[Note Name|Custom Display Text]]`. Sphene automatically builds a live relational graph and cross-references backlinks at the bottom of every note.

---

## ⌨️ Essential Keyboard Shortcuts

| Action | Shortcut | Description |
| :--- | :--- | :--- |
| **Quick Search** | `Ctrl + K` / `Cmd + K` | Sub-millisecond FTS5 search across all partitions |
| **New Note** | `Alt + N` | Instantly create a note in active partition |
| **New Drawing** | Click `+Draw` | Open the interactive canvas studio |
| **Save Document** | `Ctrl + S` / `Cmd + S` | Persist note with atomic SQLite WAL indexing |
| **Toggle Mode** | `Ctrl + E` | Switch between Markdown Editor and Reading Mode |

> [!IMPORTANT]
> Because Sphene is an open filesystem vault, any changes made from Obsidian, Logseq, VS Code, or command-line tools are indexed automatically within milliseconds.
