---
title: System Architecture
partition: Workspace
tags: [architecture, diagram, drawing, canvas]
created: 2026-09-18
---

# System Architecture & Flow Diagram

> 🎨 Interactive visual drawing created in Sphene Drawing Studio.

```mermaid
flowchart LR
    client["Web Client (PWA)"] --> gateway["API Gateway"]
    gateway --> auth{"Zero-Trust Auth"}
    auth -->|Authorized| kernel(["Sphene Kernel"])
    auth -->|Invalid Token| reject["Reject (401)"]
    kernel --> sqlite[("SQLite WAL Engine")]
    kernel --> hermes["Hermes AI Agent"]
```

## Diagram Components
- **Web Client (PWA)**: Desktop & Mobile UI
- **API Gateway**: REST, Stdio MCP & WebSocket
- **Zero-Trust Auth**: Argon2id Session & API Key Validator
- **Sphene Kernel**: In-Memory Relational Coordinator
- **SQLite WAL Engine**: Persistent Differential Storage
- **Hermes AI Agent**: Sovereign AI Assistant Connection

<!-- SPHENE_DRAWING_DATA: {"version": 1, "elements": [{"id": "node_1", "type": "box", "x": 60, "y": 90, "w": 180, "h": 65, "text": "Web Client (PWA)", "color": "#00f0ff"}, {"id": "node_2", "type": "box", "x": 290, "y": 90, "w": 170, "h": 65, "text": "API Gateway", "color": "#a855f7"}, {"id": "node_3", "type": "diamond", "x": 510, "y": 80, "w": 160, "h": 85, "text": "Zero-Trust Auth", "color": "#eab308"}, {"id": "node_4", "type": "circle", "x": 730, "y": 90, "w": 160, "h": 65, "text": "Sphene Kernel", "color": "#10b981"}, {"id": "node_5", "type": "box", "x": 510, "y": 220, "w": 160, "h": 50, "text": "Reject (401)", "color": "#ef4444"}, {"id": "node_6", "type": "box", "x": 950, "y": 60, "w": 170, "h": 55, "text": "SQLite WAL Engine", "color": "#3b82f6"}, {"id": "node_7", "type": "box", "x": 950, "y": 140, "w": 170, "h": 55, "text": "Hermes AI Agent", "color": "#ec4899"}, {"id": "conn_1", "type": "arrow", "from": "node_1", "to": "node_2", "text": ""}, {"id": "conn_2", "type": "arrow", "from": "node_2", "to": "node_3", "text": ""}, {"id": "conn_3", "type": "arrow", "from": "node_3", "to": "node_4", "text": "Valid"}, {"id": "conn_4", "type": "arrow", "from": "node_3", "to": "node_5", "text": "Invalid"}, {"id": "conn_5", "type": "arrow", "from": "node_4", "to": "node_6", "text": "WAL"}, {"id": "conn_6", "type": "arrow", "from": "node_4", "to": "node_7", "text": "MCP"}]} -->
