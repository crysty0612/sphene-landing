---
name: sphene-knowledge-hub
description: >-
  Read, search, create, update, and manage notes, documents, and knowledge in Sphene Knowledge Hub
  (the user's second brain, document store, and knowledge vault). Use whenever the user asks to save
  a document, save as MD, create or read notes, record in their second brain, log daily notes, or
  query the knowledge graph.
version: 1.1.0
metadata:
  hermes:
    tags: [Documents, Notes, Markdown, SecondBrain, KnowledgeBase, Vault, Sphene, DailyNotes]
---

# Sphene Knowledge Substrate (Documents IN & OUT)

Sphene is the user's unified knowledge substrate, document store, and second brain. It stores persistent knowledge as human-auditable, interconnected Markdown files with [[Wikilinks]].

The `sphene` CLI command is globally available in your environment (`sphene`).

## When to Use Sphene

Use Sphene whenever the user asks you to:
- **Save a document or note** ("save as document", "save as MD", "save to my second brain", "record in my knowledge vault", "take a note of this")
- **Read or retrieve documents** ("read note X", "get document Y", "show my notes on Z")
- **Search knowledge** ("search my notes for ...", "what documents do I have on ...")
- **Log to daily notes** ("save a daily brief", "log this to today's daily note", "morning brief")
- **Inspect knowledge graph** ("show knowledge graph", "check backlinks to note X")

## Commands

### 1. Save or Update a Document (Documents IN)
```bash
sphene write "<Title>" --body "<Markdown Body>" --tags "<tag1,tag2>" [--slug "<folder/slug>"]
```
- Example:
  ```bash
  sphene write "Service Mesh Architecture" \
    --tags "architecture,mesh" \
    --body "Core topology. Connects with [[Database Migration]] and [[Ingestion Worker]]."
  ```

### 2. Search Documents & Notes (Documents OUT)
```bash
sphene search "<query>"
```

### 3. Read a Document / Note (Documents OUT)
```bash
sphene read "<slug>"
```

### 4. Log to Today's Daily Note
```bash
sphene daily --brief "<Brief summary of agent work or daily log entry>"
```

### 5. Inspect Knowledge Graph & Backlinks
```bash
sphene graph
sphene backlinks "<slug>"
```

## Governance & Territory
- `00_System/`: Machine memory and scratchpads.
- `10_SecondBrain_Karpathy/`: Shared technical knowledge, architectures, and post-mortems.
- `20_Human_Thinking/`: Strictly protected human cognitive space. Do not write here unless the user explicitly requests it.
