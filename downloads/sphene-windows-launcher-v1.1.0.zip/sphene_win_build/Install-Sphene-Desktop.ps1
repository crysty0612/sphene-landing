Write-Host "Creating Sphene Knowledge Hub Desktop Shortcut..." -ForegroundColor Cyan
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$Home\Desktop\Sphene.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\Launch-Sphene.bat"
$Shortcut.Description = "Sphene Knowledge Hub"
$Shortcut.Save()
Write-Host "✓ Sphene Desktop shortcut created!" -ForegroundColor Green
Start-Process "http://localhost:8743"
