@echo off
title Sphene Knowledge Hub
echo ========================================================
echo   Sphene Knowledge Hub - Sovereign Desktop Launcher
echo ========================================================
echo Checking for local Sphene engine...
start http://localhost:8743
exit
